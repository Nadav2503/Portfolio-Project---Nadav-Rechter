document.getElementById("two-player").addEventListener("click", () => {
    window.location.href = "./playerGame.html";
});

document.getElementById("player-vs-computer").addEventListener("click", () => {
    window.location.href = "./computerGame.html";
});

document.getElementById("leaderboard").addEventListener("click", () => {
    window.location.href = "./leaderboard.html";
});
